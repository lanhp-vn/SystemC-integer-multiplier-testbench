SystemC Integer Multiplier Model and Test Bench

Description of the Model: This project implements an integer multiplier in SystemC, structured into three key modules:

- Stimulus (Stim): This module generates input test vectors for the multiplier. It sends values for two integer signals (a and b) to the multiplier module.
- Multiplier (Mult): This is the design-under-test (DUT) which performs integer multiplication of two inputs (a and b) and outputs the result (f).
- Monitor (Mon): This module monitors the output from the multiplier, checks the correctness of the multiplication, and prints the values of the input and output signals. The monitor ensures the correct timing by using the falling edge of the clock signal.

The test bench is defined by a top-level module (Top) that connects the stimulus, multiplier, and monitor modules. The simulation runs for 8 test cases, multiplying pairs of integers such as 1*42, 2*21, 3*14, and 6*7.

Source Code Files:

- top.h, top.cpp: Define the top-level module that connects the stimulus, multiplier, and monitor modules.
- mult.h, mult.cpp: Define the multiplier module, which performs the integer multiplication.
- stim.h, stim.cpp: Define the stimulus module, which provides the input test vectors.
- mon.h, mon.cpp: Define the monitor module, which checks the multiplier output and prints the results.
- main.cpp: Entry point for the SystemC simulation.

Issues Encountered:
- mon.cpp needs a while loop to keep multiplying the provided integer pairs, otherwise the simulation stops at time = 0 ns.
- It takes half of the self-set testclock period to initiate the first integer multiplicaiton (eg. testclock period = 20 ns -> first equation at time = 10 ns.
- Two integer signals (a, b) in all source code files must be similar in capitalization.

Simulating the Model - To compile and run the simulation:

1. Run `make all` to compile the model.
2. Run `make test` to execute the simulation.
-> The simulation output should display the input values and computed results for each test case, validating the functionality of the multiplier.
